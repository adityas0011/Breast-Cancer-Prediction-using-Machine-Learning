# Breast-Cancer-Prediction

Diagnosing Malignant versus Benign Breast Tumours via Machine Learning Techniques in High Dimensions

Files:
Classification.py : Logistc Regression, SVM and Decision Tree methods to classify data
